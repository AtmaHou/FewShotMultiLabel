from utils import *

experiment_name = 'bilstm_NWP'
tasks = {
    'ner': 4,
    'snips': 7
}
num_seeds = 3
dir_path = './log/'

def get_total_test_line(all_lines: [str]) -> str:
    for line in all_lines:
        if 'total test f1' in line:
            return line
    return ''


if __name__ == '__main__':
    all_lines_of_all_logs = {}
    summary_lines_of_all_logs = {}

    print('Average FB1 scores for %s' % experiment_name)
    for task in tasks.keys():
        num_task_idxes = tasks[task]
        for task_idx in range(num_task_idxes):
            task_idx = task_idx + 1
            for seed_idx in range(num_seeds):
                seed_idx = seed_idx + 1
                file_path = get_file_path(dir_path, experiment_name, task, task_idx, seed_idx)
                task_id = '%s_test_%d_seed_%d' % (task, task_idx, seed_idx)


                all_lines = get_all_lines(file_path)

                total_test_line = get_total_test_line(all_lines)
                if total_test_line == '':
                    print('- `%s` - Something went wrong, please investigate further' % task_id)
                else:
                    total_test_f1 = float(total_test_line.split()[-1])
                    print('- `%s` - %.2f' % (task_id, total_test_f1))
