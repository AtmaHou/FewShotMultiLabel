def get_file_path(dir_path: str, experiment_name: str, task: str, task_idx: int, seed_idx) -> str:
    return '%s%s.%s_test_%d_seed_%d.log' % (dir_path, experiment_name, task,
                                           task_idx, seed_idx)

def get_all_lines(file_path: str, starts_with_b=False) -> [str]:
    lines = []
    try:
        with open(file_path, encoding='utf-8') as f:
            if starts_with_b:
                for line in f:
                    if line.startswith('b\''):
                        line = line[2:-4]
                        lines.append(line)
            else:
                for line in f:
                    lines.append(line)


        return lines
    except FileNotFoundError:
        # print('%s cannot be found' % file_path)
        return []

def str2bool(v):
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise
    argparse.ArgumentTypeError('Boolean value expected.')
