#!/usr/bin/env bash

if [ $# -eq 0 ]
  then
    echo "No arguments supplied"
    exit 1
fi

dst_file=$1_analysis.txt

if [ -f ${dst_file} ]; then
    rm ${dst_file}
fi

python case_by_case_result_analyzer.py --task_name $1 >> ${dst_file}
