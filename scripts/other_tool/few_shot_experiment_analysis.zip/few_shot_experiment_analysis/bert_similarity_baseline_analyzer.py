from utils import *

experiment_name = 'similarity_bert_NWP_concise'
tasks = {
    'ner': 4,
    'snips': 7
}
dir_path = './log/'


def get_summary_lines(all_lines: [str]) -> [str]:
    summary_lines = []
    for line in all_lines:
        if line.startswith('accuracy:'):
            summary_lines.append(line)
    return summary_lines


def get_fb1_from_summary_line(summary_line: str) -> str:
    loc = summary_line.find('FB1')
    segment = summary_line[loc:]
    return segment.split(':')[1].strip()


def get_avg_fb1_from_task(summary_lines: [str]) -> str:
    total_fb1 = 0.0
    for summary_line in summary_lines:
        fb1_score = float(get_fb1_from_summary_line(summary_line))
        total_fb1 += fb1_score

    return '%.2f' % (total_fb1 / len(summary_lines))


if __name__ == '__main__':
    all_lines_of_all_logs = {}
    summary_lines_of_all_logs = {}

    for task in tasks.keys():
        num_task_idxes = tasks[task]
        for task_idx in range(num_task_idxes):
            task_idx = task_idx + 1
            file_path = get_file_path(dir_path, experiment_name, task, task_idx, 2)
            task_id = '%s_test_%d_seed_2' % (task, task_idx)

            all_lines = get_all_lines(file_path, True)
            all_lines_of_all_logs[task_id] = all_lines

    for task_id in all_lines_of_all_logs.keys():
        all_lines = all_lines_of_all_logs[task_id]
        summary_lines = get_summary_lines(all_lines)
        summary_lines_of_all_logs[task_id] = summary_lines

    print('Average FB1 scores for %s' % experiment_name)
    for task_id in summary_lines_of_all_logs.keys():
        summary_lines = summary_lines_of_all_logs[task_id]
        avg_fb1 = get_avg_fb1_from_task(summary_lines)
        print('- `%s` - %s' % (task_id, avg_fb1))

