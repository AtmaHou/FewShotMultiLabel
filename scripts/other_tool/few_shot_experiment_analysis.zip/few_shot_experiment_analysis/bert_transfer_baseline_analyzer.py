import argparse

from utils import *

experiment_name = 'transfer-BLOCK-Ture_NWP'
tasks = {
    'ner': 4,
    'snips': 7
}
num_seeds = 3
dir_path = './log/'

def get_average_test_f1_line(all_lines: [str]) -> str:
    for line in all_lines:
        if 'Average test F1' in line:
            return line
    return ''


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="")
    parser.add_argument('-crf', type=str2bool, nargs='?', const=True, default=False)

    args = parser.parse_args()
    
    if args.crf:
        experiment_name = 'crf-' + experiment_name

    all_lines_of_all_logs = {}
    summary_lines_of_all_logs = {}

    print('Average FB1 scores for %s' % experiment_name)
    for task in tasks.keys():
        num_task_idxes = tasks[task]
        for task_idx in range(num_task_idxes):
            task_idx = task_idx + 1
            for seed_idx in range(num_seeds):
                seed_idx = seed_idx + 1
                file_path = get_file_path(dir_path, experiment_name, task, task_idx, seed_idx)
                task_id = '%s_test_%d_seed_%d' % (task, task_idx, seed_idx)


                all_lines = get_all_lines(file_path)

                average_test_f1_line = get_average_test_f1_line(all_lines)
                if average_test_f1_line == '':
                    print('- `%s` - Something went wrong, please investigate further' % task_id)
                else:
                    average_test_f1 = float(average_test_f1_line.split()[-1])
                    print('- `%s` - %.2f' % (task_id, average_test_f1))
