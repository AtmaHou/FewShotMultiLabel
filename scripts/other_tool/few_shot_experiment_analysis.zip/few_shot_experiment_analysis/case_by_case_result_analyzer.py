import argparse
from typing import Dict


base_dir_path = 'results'


def get_predictions_dir_path(experiment_name: str, dataset_name: str, seed: str, predictions_path: str) -> str:
    if predictions_path:
        return '%s/%s' % (base_dir_path, predictions_path)

    if 'snips' in dataset_name:
        return '%s/xval_snips/%s.%s_seed_%s' % (base_dir_path, experiment_name, dataset_name, seed)
    else:
        return '%s/xval_ner/%s.%s_seed_%s' % (base_dir_path, experiment_name, dataset_name, seed)


def get_prediction_segments(predictions_dir_path: str) -> [[str]]:
    prediction_segments = []
    prediction_segment = []

    for i in range(100):
        prediction_file_path = '%s/test_pred.%d.txt' % (predictions_dir_path, i)
        try:
            with open(prediction_file_path, 'r', encoding='utf-8') as f:
                for line in f:
                    if line == '\n':
                        if prediction_segment:
                            prediction_segments.append(prediction_segment)
                            prediction_segment = []
                    else:
                        prediction_segment.append(line)
                if prediction_segment:
                    prediction_segments.append(prediction_segment)
                    prediction_segment = []
        except FileNotFoundError:
            pass

    return prediction_segments


def split_tag(tag: str) -> (str, str):
    if tag == 'O':
        return 'O', None
    return tuple(tag.split('-'))


def confirm_match(curr_label_tag: str, curr_prediction_tag: str) -> bool:
    return curr_label_tag == curr_prediction_tag


def handle_start_with_B(case2total: Dict[str, int], case2correct: Dict[str, int],
                        curr_label_tag: str, curr_label_tag_prefix: str, curr_label_tag_stem: str,
                        curr_prediction_tag: str, prev_label_tag_stem: str):
    if curr_label_tag_prefix == 'O':
        case2total['BO'] += 1
        if confirm_match(curr_label_tag, curr_prediction_tag):
            case2correct['BO'] += 1

    if curr_label_tag_prefix == 'B':
        if prev_label_tag_stem == curr_label_tag_stem:
            case2total['BB'] += 1
            if confirm_match(curr_label_tag, curr_prediction_tag):
                case2correct['BB'] += 1
        if prev_label_tag_stem != curr_label_tag_stem:
            case2total['Bb'] += 1
            if confirm_match(curr_label_tag, curr_prediction_tag):
                case2correct['Bb'] += 1

    if curr_label_tag_prefix == 'I':
        assert curr_label_tag_stem == prev_label_tag_stem
        case2total['BI'] += 1
        if confirm_match(curr_label_tag, curr_prediction_tag):
            case2correct['BI'] += 1


def handle_start_with_I(case2total: Dict[str, int], case2correct: Dict[str, int],
                        curr_label_tag: str, curr_label_tag_prefix: str, curr_label_tag_stem: str,
                        curr_prediction_tag: str, prev_label_tag_stem: str):
    if curr_label_tag_prefix == 'O':
        case2total['IO'] += 1
        if confirm_match(curr_label_tag, curr_prediction_tag):
            case2correct['IO'] += 1

    if curr_label_tag_prefix == 'B':
        if prev_label_tag_stem == curr_label_tag_stem:
            case2total['IB'] += 1
            if confirm_match(curr_label_tag, curr_prediction_tag):
                case2correct['IB'] += 1
        if prev_label_tag_stem != curr_label_tag_stem:
            case2total['Ib'] += 1
            if confirm_match(curr_label_tag, curr_prediction_tag):
                case2correct['Ib'] += 1

    if curr_label_tag_prefix == 'I':
        assert curr_label_tag_stem == prev_label_tag_stem
        case2total['II'] += 1
        if confirm_match(curr_label_tag, curr_prediction_tag):
            case2correct['II'] += 1


def handle_start_with_O(case2total: Dict[str, int], case2correct: Dict[str, int],
                        curr_label_tag: str, curr_label_tag_prefix: str,
                        curr_prediction_tag: str):
    if curr_label_tag_prefix == 'O':
        case2total['OO'] += 1
        if confirm_match(curr_label_tag, curr_prediction_tag):
            case2correct['OO'] += 1

    if curr_label_tag_prefix == 'B':
        case2total['OB'] += 1
        if confirm_match(curr_label_tag, curr_prediction_tag):
            case2correct['OB'] += 1


def summarize_prediction_segment(prediction_segment: [str], case2total: Dict[str, int], case2correct: Dict[str, int]):
    assert len(prediction_segment) > 0
    curr_line = prediction_segment[0]
    _, curr_label_tag, curr_prediction_tag = curr_line.split()
    curr_label_tag_prefix, curr_label_tag_stem = split_tag(curr_label_tag)
    curr_prediction_tag_prefix, curr_prediction_stem = split_tag(curr_prediction_tag)

    if curr_label_tag_prefix == 'O':
        case2total['-O'] += 1
        if confirm_match(curr_label_tag, curr_prediction_tag):
            case2correct['-O'] += 1
    else:
        assert curr_label_tag_prefix == 'B'
        case2total['-B'] += 1
        if confirm_match(curr_label_tag, curr_prediction_tag):
            case2correct['-B'] += 1

    prev_label_tag_prefix, prev_label_tag_stem = curr_label_tag_prefix, curr_label_tag_stem

    for curr_line in prediction_segment[1:]:
        _, curr_label_tag, curr_prediction_tag = curr_line.split()
        curr_label_tag_prefix, curr_label_tag_stem = split_tag(curr_label_tag)

        if prev_label_tag_prefix == 'B':
            handle_start_with_B(case2total, case2correct,
                                curr_label_tag, curr_label_tag_prefix, curr_label_tag_stem,
                                curr_prediction_tag, prev_label_tag_stem)

        if prev_label_tag_prefix == 'I':
            handle_start_with_I(case2total, case2correct,
                                curr_label_tag, curr_label_tag_prefix, curr_label_tag_stem,
                                curr_prediction_tag, prev_label_tag_stem)

        if prev_label_tag_prefix == 'O':
            handle_start_with_O(case2total, case2correct,
                                curr_label_tag, curr_label_tag_prefix,
                                curr_prediction_tag)

        prev_label_tag_prefix, prev_label_tag_stem = curr_label_tag_prefix, curr_label_tag_stem


def summarize_prediction_segments(prediction_segments: [[str]], case2total: Dict[str, int], case2correct: Dict[str, int]):
    for prediction_segment in prediction_segments:
        summarize_prediction_segment(prediction_segment, case2total, case2correct)


def calculate_accuracies(case2total: Dict[str, int], case2correct: Dict[str, int], case2accuracies: Dict[str, float]):
    for case in case2total.keys():
        case2accuracies[case] = float(case2correct[case]) / float(case2total[case]) if case2total[case] != 0 else 1.


def gather_information_for_one_pred_set(experiment_name: str, dataset_name:
                                        str, seed: str, predictions_path: str) -> (Dict[str,
                                                                                        int],
                                                                                   Dict[str,
                                                                                        int],
                                                                                   Dict[str,
                                                                                        float]):
    case2total = {
        'IO': 0,
        'IB': 0,
        'Ib': 0,
        'II': 0,
        'OO': 0,
        'OB': 0,
        'BO': 0,
        'BB': 0,
        'Bb': 0,
        'BI': 0,
        '-O': 0,
        '-B': 0
    }
    case2correct = {
        'IO': 0,
        'IB': 0,
        'Ib': 0,
        'II': 0,
        'OO': 0,
        'OB': 0,
        'BO': 0,
        'BB': 0,
        'Bb': 0,
        'BI': 0,
        '-O': 0,
        '-B': 0
    }

    case2accuracies = {
        'IO': 0.,
        'IB': 0.,
        'Ib': 0.,
        'II': 0.,
        'OO': 0.,
        'OB': 0.,
        'BO': 0.,
        'BB': 0.,
        'Bb': 0.,
        'BI': 0.,
        '-O': 0.,
        '-B': 0.
    }

    predictions_dir_path = get_predictions_dir_path(experiment_name, dataset_name, seed, predictions_path)
    print('Statistics for data in directory: %s' % predictions_dir_path)
    prediction_segments = get_prediction_segments(predictions_dir_path)
    if not prediction_segments:
        print("No result found!")
        return None 
    summarize_prediction_segments(prediction_segments, case2total, case2correct)
    calculate_accuracies(case2total, case2correct, case2accuracies)

    print('Case count total       :', case2total)
    print('Case count correct     :', case2correct)
    print('Average accuracies     :', float(sum(case2correct.values()) /
                                            float(sum(case2total.values()))))
    print('Case accuracies')
    for case in case2accuracies.keys():
        print('%s\t%.4f' % (case, case2accuracies[case]))

    print('\n\n')
    return case2total, case2correct, case2accuracies


def main():
    parser = argparse.ArgumentParser(description='')
    parser.add_argument('--experiment_name', type=str, default=None)
    parser.add_argument('--dataset_name', type=str, default=None)
    parser.add_argument('--seed', type=str, default=None)
    parser.add_argument('--predictions_path', type=str, default=None)
    parser.add_argument('--task_name', type=str, default=None)

    args = parser.parse_args()
    experiment_name = args.experiment_name
    dataset_name = args.dataset_name
    seed = args.seed
    predictions_path = args.predictions_path
    task_name = args.task_name

    if task_name:
        all_information = []
        for i in range(7):
            i = i + 1
            predictions_path = '%s/snips%d' % (task_name, i)
            all_information.append(gather_information_for_one_pred_set(experiment_name, dataset_name, seed, predictions_path))
        for i in range(4):
            i = i + 1
            predictions_path = '%s/ner%d' % (task_name, i)
            all_information.append(gather_information_for_one_pred_set(experiment_name, dataset_name, seed, predictions_path))

        case2total = {}
        case2correct = {}
        case2accuracies = {}

        for information in all_information:
            if not information:
                continue

            for case in information[0].keys():
                if case not in case2total:
                    case2total[case] = 0
                case2total[case] += information[0][case]

                if case not in case2correct:
                    case2correct[case] = 0
                case2correct[case] += information[1][case]

        for case in case2total.keys():
            case2accuracies[case] = float(case2correct[case]) / float(case2total[case]) if case2total[case] != 0 else 1.

        print('\n\nSummary')
        print('Average accuracies by cases')
        for case in case2accuracies.keys():
            print('%s\t%.4f' % (case, case2accuracies[case]))
        print('Fractions of occurances of each case')
        for case in case2total.keys():
            print('%s\t%.5f' % (case, float(case2total[case]) /
                                float(sum(case2total.values()))))
    else:
        gather_information_for_one_pred_set(experiment_name, dataset_name,
                                            seed, predictions_path)


if __name__ == '__main__':
    main()
