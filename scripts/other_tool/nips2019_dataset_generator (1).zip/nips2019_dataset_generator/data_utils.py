from typing import Dict
import json

in_data_dir_path = './data/structured_data/'
file_name_rest_part = '.wp_True.seed_0.support_shots_1.batch_size_10.batch_num_100.json'


def build_file_name(dataset_name: str, section: str, dataset_type: str):
    return in_data_dir_path + '%s/' % dataset_type + '%s.' % dataset_name + '%s' % section + file_name_rest_part


def load_dataset(dataset_name: str, dataset_type: str) -> Dict:
    train_dataset = load_dataset_from_file(build_file_name(dataset_name, 'train', dataset_type))
    test_dataset = load_dataset_from_file(build_file_name(dataset_name, 'test', dataset_type))
    return merge_datasets([train_dataset, test_dataset])


def load_datasets(dataset_info: [(str, str)]) -> Dict:
    datasets = []
    for dataset_name, dataset_type in dataset_info:
        datasets.append(load_dataset(dataset_name, dataset_type))
        
    return merge_datasets(datasets)


def load_dataset_from_file(file_name: str) -> Dict:
    with open(file_name, 'r') as json_file:
        return json.load(json_file)
    
        
def merge_datasets(datasets: [Dict]) -> Dict:
    merged_dataset = dict()
    
    for dataset in datasets:
        domains = dataset.keys()
        for domain in domains:
            if domain not in merged_dataset:
                merged_dataset[domain] = []
            merged_dataset[domain].extend(dataset[domain])
            
    return merged_dataset

def write_dataset_to_file(dataset: Dict, out_data_dir_path, file_name: str):
    with open(out_data_dir_path + file_name, 'w+') as file:
        json.dump(dataset, file)
    

def run_load_dataset():
    data = load_dataset('anem', 'train', 'ner')
    print(data)

if __name__ == '__main__':
    run_load_dataset()
