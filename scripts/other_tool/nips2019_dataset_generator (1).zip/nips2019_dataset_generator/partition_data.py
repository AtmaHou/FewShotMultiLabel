from os import listdir
from os.path import isfile, join
import argparse

from data_utils import *


in_data_dir_path = './data/structured_data/'
out_data_dir_path = './data/seperated_data/'


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Obtaining partitioned data.')
    parser.add_argument('--path', default=out_data_dir_path)
    args = parser.parse_args()
    out_data_dir_path = args.path

    dataset_filenames = [f for f in listdir(in_data_dir_path)]
    if not dataset_filenames:
        print('Oops. No dataset has been found. Good bye!')
        exit()

    dataset_infos = {}

    for dataset_filename in dataset_filenames:
        if dataset_filename == '.DS_Store':
            continue

        dataset_name, dataset_type, _, _, dataset_shot_size, _, dataset_batch_num, _ = dataset_filename.split('.')

        if '%s(%s, %s)' % (dataset_name, dataset_type, dataset_shot_size) in dataset_infos:
            raise FileExistsError
        dataset_infos['%s(%s|%s|%s)' % (dataset_name, dataset_type, dataset_shot_size, dataset_batch_num)] = \
            in_data_dir_path + dataset_filename

    idx2infokey = {}
    idx = 1
    print('Hey! The following datasets have been found.')
    for dataset_info in dataset_infos.keys():
        print('%d\t%s' % (idx, dataset_info))
        idx2infokey[idx] = dataset_info
        idx += 1

    print('Please lemme know which dataset(s) you want to merge, with a comma between each dataset')
    print('Example: 1, 3')

    dataset_filenames = input()
    dataset_filenames = dataset_filenames.split(',')
    dataset_filenames = [idx2infokey[int(dataset_filename.strip())] for dataset_filename in dataset_filenames]
    dataset_filenames = [dataset_infos[dataset_info] for dataset_info in dataset_filenames]
    print('Okay, got it. I will now merge the dataset and then provide you a list of domain names'
          ' in the datasets you chose')
    print(dataset_filenames)
    print('Working...')
    datasets = []
    for dataset_filename in dataset_filenames:
        datasets.append(load_dataset_from_file(dataset_filename))
    merged_dataset = merge_datasets(datasets)
    domains = list(merged_dataset.keys())

    idx2domain = {}
    idx = 1
    print('Done! Below is a list of domains in all of the datasets.')
    for domain in domains:
        print('%d\t%s - %s' % (idx, domain, '%d batches' % len(merged_dataset[domain])))
        idx2domain[idx] = domain
        idx += 1

    while True:
        print('Now, please let me know which domains you would like to use for a new dataset?')
        print('Example: %s' % ('%d,%d' % (1, 2)))
        selected_domains = input()
        print('Got it. Working on generating the new dataset...')
        selected_domains = selected_domains.split(',')
        selected_domains = [idx2domain[int(selected_domain.strip())] for selected_domain in selected_domains]
        print(selected_domains)
        new_dataset = {}
        for selected_domain in selected_domains:
            new_dataset[selected_domain] = merged_dataset[selected_domain]
        print('And what should be the name for this new dataset?')
        new_dataset_filename = input()
        write_dataset_to_file(new_dataset, out_data_dir_path, new_dataset_filename + '.json')
        print('Great! Now you can find the new dataset in this directory: %s' % out_data_dir_path)
